import tkinter as tk
from tkinter import messagebox, Toplevel, Label, Button, Listbox, Scrollbar, Entry
import quiz_data
import random

  
class PlayerDashboard:
  def __init__(self):
    self.player_window = tk.Toplevel()
    self.player_window.title("Player Dashboard")
    self.player_window.geometry("400x400")
    self.player_window.configure(background='light grey')

    self.questions_and_answers = quiz_data.questions_and_answers
    self.user_answer = ""
    
    self.selected_category = tk.StringVar()
    self.selected_category.set(self.questions_and_answers[0]["category"])

    self.question_label = None
    
    self.lives = 3
    self.score = 0  
    self.current_category = None
    self.current_questions = []
    self.current_question_index = 0

    self.create_widgets()

  def create_widgets(self):
    tk.Label(self.player_window, text="Welcome to the Player Dashboard!", bg='light grey').pack(pady=20)

    tk.Label(self.player_window, text="Select Category:").pack(pady=5)
    self.category_listbox = Listbox(self.player_window, selectmode="single", height=len(self.questions_and_answers))
    self.category_listbox.pack(pady=5)
    scrollbar = Scrollbar(self.player_window, orient="vertical", command=self.category_listbox.yview)
    scrollbar.pack(side="right", fill="y")
    self.category_listbox.config(yscrollcommand=scrollbar.set)
    for category_data in self.questions_and_answers:
      self.category_listbox.insert(tk.END, 
                                         category_data["category"])
    self.category_listbox.bind('<<ListboxSelect>>', self.on_category_select)

        # Question display
      ##  self.question_label = tk.Label(self.player_window, text="", wraplength=380, justify="left")
     ##   self.question_label.pack(pady=10)

        # Answer entry(blank for now)
       ## tk.Label(self.player_window, text="Enter Answer:").pack(pady=5)
      ##  self.answer_entry = Entry(self.player_window)
    ##    self.answer_entry.pack(pady=5)

        # Submit answer button
    confirm_category_button = Button(self.player_window, text="Confirm Category", command=self.confirm_category)
    confirm_category_button.pack(pady=10)

        
    tk.Label(self.player_window, text="Lives Remaining:").pack()
    self.lives_label = tk.Label(self.player_window, text=str(self.lives))
    self.lives_label.pack()

     

  

  

    
  def on_category_select(self, event):
    selected_index = self.category_listbox.curselection()
    if selected_index:
        selected_category =  self.questions_and_answers[selected_index[0]]["category"]
        self.selected_category.set(selected_category)
      
  def get_question_by_difficulty(self, difficulty):
    selected_category = self.selected_category.get()
    
    matching_questions = [q for category in self.questions_and_answers
                          if category["category"] == selected_category
                          for q in category["questions"] if q["difficulty"] == difficulty]

    if matching_questions:
        question = random.choice(matching_questions)
        correct_answer = question["answer"]
        return question["question"]

    return "No question available for this difficulty in the selected category."

  def display_question_diff(self, difficulty, label):
    question = self.get_question_by_difficulty(difficulty)

    top = tk.Toplevel()
    top.title("Question")
    top.geometry("400x400")
    
    label = tk.Label(top, text=question, wraplength=380, justify="left")
    label.pack(pady=10)
    label.config(text=question)

    final_answer = Label(top, text = "Final Answer: ").place(x = 40, y = 60)
    answer_entry = tk.Entry(top, width = 30).place(x = 122, y = 60)

    self.user_answer = answer_entry
    
    

    submit_button = tk.Button(top, text="Submit Answer", command=lambda: self.check_answer(answer_entry))
    submit_button.pack(pady=70)

                            
  def check_answer(self, correct_answer):
    user_answer = self.user_answer.get()
    if user_answer.lower() == correct_answer.lower():
      self.score += 1
      messagebox.showinfo("Correct", "Your answer is correct!")
    else:
      self.lives -= 1
      messagebox.showerror("Incorrect", "Your answer is incorrect!")

    if self.lives == 0:
      messagebox.showinfo("Game Over", "Game Over! Your score is " + str(self.score))
      self.player_window.destroy()
    
      

    
    
      
  

    
    

 
    

  
  def confirm_category(self):
    top = tk.Toplevel()
    top.title("Choose Your Difficulty")
    top.geometry("400x250")
    top.configure(background='light grey')

    difficulties = ["100", "200", "300", "400", "500"]
    
    for difficulty in difficulties:
      button = tk.Button(top, text=f"{difficulty} points", command=lambda d=difficulty: self.display_question_diff(d, self.question_label))  # 
      button.pack(pady=10)  # Add some vertical padding between buttons




