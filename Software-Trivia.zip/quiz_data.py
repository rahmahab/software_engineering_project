questions_and_answers = [
  
      {
        "category": "Sports",
        "questions": [
              {
                "question": "Which country won the FIFA World Cup in 2018?",
                  "answer": "France",
                  "difficulty": "200"
              },
              {
                  "question": "Who holds the record for the fastest 100-meter sprint?",
                  "answer": "Usain Bolt",
                  "difficulty": "100"
              },
              {
                  "question": "Which sport is played at Wimbledon?",
                  "answer": "Tennis",
                  "difficulty": "200"
              },
              {
                  "question": "Which team won the first ever Super Bowl?",
                  "answer": "Green Bay Packers",
                  "difficulty": "300"
              },
              {
                  "question": "Who won the 2020 NBA Championship?",
                  "answer": "Los Angeles Lakers",
                  "difficulty": "200"
              },
              {
                  "question": "Which country has won the most Olympic gold medals?",
                  "answer": "United States",
                  "difficulty": "200"
              },
              {
                  "question": "Who is the all-time leading scorer in the NHL?",
                  "answer": "Wayne Gretzky",
                  "difficulty": "200"
              },
              {
                  "question": "Which athlete won the most gold medals in a single Olympic Games?",
                  "answer": "Michael Phelps",
                  "difficulty": "200"
              },
              {
                  "question": "What is the most popular sport in Brazil?",
                  "answer": "Football",
                  "difficulty": "100"
              },
              {
                  "question": "Which boxer is known as 'The Greatest of All Time'?",
                  "answer": "Muhammad Ali",
                  "difficulty": "100"
              }
          ]
      },
      {
          "category": "Music Category",
          "questions": [
              {
                  "question": "Who is known as the 'Queen of Pop'?",
                  "answer": "Madonna",
                  "difficulty": "200"
              },
              {
                  "question": "Which band released the album 'Abbey Road'?",
                  "answer": "The Beatles",
                  "difficulty": "200"
              },
              {
                  "question": "Who sang the hit song 'Billie Jean'?",
                  "answer": "Michael Jackson",
                  "difficulty": "100"
              },
              {
                  "question": "What is the best-selling album of all time?",
                  "answer": "Thriller",
                  "difficulty": "200"
              },
              {
                  "question": "Who wrote the song 'Bohemian Rhapsody'?",
                  "answer": "Freddie Mercury",
                  "difficulty": "200"
              },
              {
                  "question": "Which rapper's real name is Marshall Mathers?",
                  "answer": "Eminem",
                  "difficulty": "100"
              },
              {
                  "question": "Who is known as the 'King of Rock and Roll'?",
                  "answer": "Elvis Presley",
                  "difficulty": "200"
              },
              {
                  "question": "Which singer's real name is Robyn Fenty?",
                  "answer": "Rihanna",
                  "difficulty": "100"
              },
              {
                  "question": "What is the name of Adele's debut album?",
                  "answer": "19",
                  "difficulty": "200"
              },
              {
                  "question": "Which musician played the character Jack Dawson in the film 'Titanic'?",
                  "answer": "Celine Dion",
                  "difficulty": "300"
              }
          ]
      },
      # Continue for other categories following the same format
  
    {
        "category": "Movies/ TV shows category",
        "questions": [
            {
                "question": "What is the highest-grossing film of all time (not adjusted for inflation)?",
                "answer": "Avatar",
                "difficulty": "200"
            },
            {
                "question": "Who played the character Tony Stark in the Marvel Cinematic Universe films?",
                "answer": "Robert Downey Jr.",
                "difficulty": "200"
            },
            {
                "question": "Which TV show features characters named Ross, Rachel, Chandler, Monica, Joey, and Phoebe?",
                "answer": "Friends",
                "difficulty": "200"
            },
            {
                "question": "Who directed the movie 'The Shawshank Redemption'?",
                "answer": "Frank Darabont",
                "difficulty": "400"
            },
            {
                "question": "Which actress played Katniss Everdeen in 'The Hunger Games' films?",
                "answer": "Jennifer Lawrence",
                "difficulty": "200"
            },
            {
                "question": "What is the name of the fictional continent in 'Game of Thrones'?",
                "answer": "Westeros",
                "difficulty": "300"
            },
            {
                "question": "Who won the Academy Award for Best Actor for his role in 'The Revenant'?",
                "answer": "Leonardo DiCaprio",
                "difficulty": "200"
            },
            {
                "question": "What is the longest-running animated TV show in history?",
                "answer": "The Simpsons",
                "difficulty": "100"
            },
            {
                "question": "Who played the character Walter White in the TV series 'Breaking Bad'?",
                "answer": "Bryan Cranston",
                "difficulty": "300"
            },
            {
                "question": "Which movie features a character named 'Forrest Gump'?",
                "answer": "Forrest Gump",
                "difficulty": "100"
            }
        ]
    },
    # Programming category
    {
        "category": "Programming",
        "questions": [
            {
                "question": "What does HTML stand for?",
                "answer": "Hypertext Markup Language",
                "difficulty": "200"
            },
            {
                "question": "Which programming language is often used for artificial intelligence?",
                "answer": "Python",
                "difficulty": "200"
            },
            {
                "question": "What is the purpose of the 'if' statement in programming?",
                "answer": "Conditional execution",
                "difficulty": "200"
            },
            {
                "question": "What is the name of the version control system developed by Linus Torvalds?",
                "answer": "Git",
                "difficulty": "300"
            },
            {
                "question": "What is the main function in most programming languages?",
                "answer": "Entry point of the program",
                "difficulty": "200"
            },
            {
                "question": "Which programming language is primarily used for web development?",
                "answer": "JavaScript",
                "difficulty": "100"
            },
            {
                "question": "What does CSS stand for?",
                "answer": "Cascading Style Sheets",
                "difficulty": "200"
            },
            {
                "question": "What is the process of finding errors and fixing them in a program called?",
                "answer": "Debugging",
                "difficulty": "300"
            },
            {
                "question": "What is the term for a named block of code that performs a specific task?",
                "answer": "Function",
                "difficulty": "300"
            },
            {
                "question": "What is the file extension for Python files?",
                "answer": ".py",
                "difficulty": "200"
            }
        ]
    },

    {
        "category": "HU Knowledge",
        "questions": [
            {
                "question": "What is the mascot of Howard University?",
                "answer": "Bison",
                "difficulty": "100"
            },
            {
                "question": "What is the name of the tallest building on Howard University's campus?",
                "answer": "Howard Center",
                "difficulty": "300"
            },
            {
                "question": "In which city is Howard University located?",
                "answer": "Washington, D.C.",
                "difficulty": "200"
            },
            {
                "question": "Who founded Howard University?",
                "answer": "Oliver O. Howard",
                "difficulty": "300"
            },
            {
                "question": "What year was Howard University founded?",
                "answer": "1867",
                "difficulty": "200"
            },
            {
                "question": "What is the official motto of Howard University?",
                "answer": "Veritas et Utilitas",
                "difficulty": "400"
            },
            {
                "question": "What is the Howard University School of Business named after?",
                "answer": "Thurgood Marshall",
                "difficulty": "300"
            },
            {
                "question": "Which HU alumnus was the first African American Supreme Court Justice?",
                "answer": "Thurgood Marshall",
                "difficulty": "200"
            },
            {
                "question": "What is the name of the homecoming celebration at Howard University?",
                "answer": "Yardfest",
                "difficulty": "200"
            },
            {
                "question": "Which US president delivered the commencement address at Howard University in 2016?",
                "answer": "Barack Obama",
                "difficulty": "200"
            }
        ]
    },
    # FAANG Facts category
    {
        "category": "FAANG Facts",
        "questions": [
            {
                "question": "Which company's CEO famously said 'Think Different'?",
                "answer": "Apple",
                "difficulty": "200"
            },
            {
                "question": "Who founded Amazon?",
                "answer": "Jeff Bezos",
                "difficulty": "100"
            },
            {
                "question": "What was Google's original name?",
                "answer": "BackRub",
                "difficulty": "300"
            },
            {
                "question": "What was Facebook's original name?",
                "answer": "TheFacebook",
                "difficulty": "300"
            },
            {
                "question": "Which streaming service was founded by Reed Hastings and Marc Randolph?",
                "answer": "Netflix",
                "difficulty": "300"
            },
            {
                "question": "Who is the current CEO of Apple?",
                "answer": "Tim Cook",
                "difficulty": "100"
            },
            {
                "question": "What was the first product ever sold on Amazon?",
                "answer": "A book",
                "difficulty": "400"
            },
            {
                "question": "Which FAANG company was founded by Larry Page and Sergey Brin?",
                "answer": "Google",
                "difficulty": "300"
            },
            {
                "question": "Which FAANG company was founded by Mark Zuckerberg?",
                "answer": "Facebook",
                "difficulty": "100"
            },
            {
                "question": "Who co-founded Apple Inc. alongside Steve Jobs and Steve Wozniak?",
                "answer": "Ronald Wayne",
                "difficulty": "300"
            }
        ]
    }
]





