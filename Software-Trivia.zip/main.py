import tkinter as tk
from quiz_data import questions_and_answers
from tkinter import messagebox, Button, TOP
from admin_dashboard import AdminDashboard
from player_dashboard import PlayerDashboard
import hashlib




def sign_in(user_type):
  if user_type == "admin":
    AdminDashboard()
  elif user_type == "player": 
    PlayerDashboard()
  else:
    messagebox.showerror("Error", "Invalid input. Please try again.")
    
class Interface:
  
  def __init__(self, password):
    self.password = password

 ### def sign_in(user_type):
 ##   if user_type == "admin":
 ##     AdminDashboard()
 ##   elif user_type == "player":
 ##     PlayerDashboard()
 ##   else:
 ##     messagebox.showerror("Error", "Invalid input. Please try again.")

root = tk.Tk()
root.title("Sign In Page")
root.geometry("400x200")
root.configure(background='light grey')

label = tk.Label(root, text= "Welcome to the Jeopardy Game!\nAre you a player or Administrator?", bg='light grey')
label.pack(pady=10)

admin_button = Button(root, text="Admin", command=lambda: sign_in("admin"))
admin_button.pack(pady=5, side=TOP)

player_button = Button(root, text="Player", command=lambda: sign_in("player"))
player_button.pack(pady=5, side=TOP)

root.mainloop()
