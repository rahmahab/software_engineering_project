import tkinter as tk
from tkinter import Toplevel, Entry, Label, Button
import hashlib

class AdminDashboard:
    def __init__(self):
        self.admin_window = tk.Toplevel()
        self.admin_window.title("Administrator Dashboard")
        self.admin_window.geometry("300x200")
        self.admin_window.configure(background='light grey')
        tk.Label(self.admin_window, text="Welcome to the Administrator Dashboard!", bg='light grey').pack(pady=20)


        self.admin_login()

    def admin_login(self):
        # Implement the admin login functionality here
        tk.Label(self.admin_window, text="Please enter username: ").pack(pady=5)  
        self.admin_username = Entry(self.admin_window)
        self.admin_username.pack(pady=5) 
        tk.Label(self.admin_window, text="Please enter password: ").pack(pady=5)
        self.admin_password = Entry(self.admin_window, show="*")
        self.admin_password.pack(pady=5)

        username = self.admin_username.get()
        password = self.admin_password.get()

        auth = password.encode()
        auth_hash = hashlib.md5(auth).hexdigest()
        with open("login_data.txt", "r") as f:
          saved_username, saved_password = f.read().split("\n")
        f.close()

        if username == saved_username and auth_hash == hashlib.md5(saved_password.encode()).hexdigest():
          print("Logged in Successfully!")
        else:
          print("Login failed! \n")

  

   
